/** @file Plot.cpp
 *  @brief LaTeX tikz plotting utility routines for the EMPA processor simulator.
 *
 *  @author János Végh (jvegh)
 *  @bug No known bugs.
 */
#include <fstream>      // std::ifstream
//#include <iomanip>      // std::setfill, std::setw#include <fstream>
#include <glog/logging.h>
#include "Plot.h"
#include "../main/include/Config.h"
#include "include/stuff.h"

// These streams store the "upper level" plotting until drawing done
ostringstream MetaString, ExecString,QTstring,WaitString;
ofstream plotfile;		// Not related to simulation, just makes 'gpf/tikz' plots
string PlotMessage;	// The early string, before opening logging
extern bool UNIT_TESTING;
using namespace std;

/** @class	EMPAPlotter 
 * @brief The class prepares publication quality figures, using LaTeX/tikz
 *
 *  @param  argc    as in main()
 *  @param  argv    as in main()
 * 
 * The class is a collection of routines, proving an interface for the simulator
 * In unit testing mode, the interface is unchanged, but no functionality;
 * also no file is prepared
 */
EMPAPlotter::EMPAPlotter(Processor* Proc, string FileNameRoot)
{
  mProcessor = Proc;
  mSupervisor = Proc->Supervisor_Get();
  if(!UNIT_TESTING)
  {
    BeginPlotting(Proc, FileNameRoot);
  }
}

// In the destructor, the plot is finished and the file closed
EMPAPlotter::~EMPAPlotter(void)
{
  if(!UNIT_TESTING)
  { // Terminate plotting
    PlotTimeAxis();
    PrintFinalReport();
    plotfile << WaitString.str();
    plotfile << MetaString.str();
    plotfile << QTstring.str();
    plotfile << ExecString.str();    
    plotfile <<
      "\\end{tikzpicture}\n"
      "}\n"
      "%\\end{figure*}\n\n"
      "\\end{document}\n"
      "\n";
    plotfile.close();
  }

}

/**
 * @brief Prints out the necessary macros, etc to to prepared plot
 * This routine is called before beginning the main processing
 * and starts writing into the prepared plot file. 
 * The file is to be compiled with pdflatex
 */
void EMPAPlotter::BeginPlotting(Processor* Proc, string FileNameRoot)
{
  if(!UNIT_TESTING)
  {
  string PlotFileName = "ProcDiagram_" + FileNameRoot + ".tex"; // Prepare log file name
  plotfile.open ("../output/"+PlotFileName);
  if(!plotfile.is_open())
  {
    LOG(ERROR) << "Plot file '" << PlotFileName << "' could not be created";
  }
  else
    LOG(INFO) << "       Processing diagram is directed to file '" << PlotFileName << "'";
    
  plotfile << "\\documentclass{standalone}\n";
  plotfile << "% % Prepared by " << GetAppName() << "\n";
  plotfile << "\\usepackage{tikz}\n";
  plotfile << "\\usetikzlibrary{arrows,shadows,backgrounds,calc,decorations.pathreplacing,decorations.pathmorphing,shapes.arrows}\n";
  plotfile << "\\usetikzlibrary{arrows, decorations.markings}\n";
  plotfile << "\\usepackage{graphicx}\n";
  plotfile << "\\usepackage{adjustbox}\n";
  plotfile << "\\definecolor{burntorange}{rgb}{0.8, 0.33, 0.0}\n"; 
  
  plotfile << "% % Put a new quasi-thread symbol to coordinates\n"
   "% % \\QTfigure{Name_index}{length}{x}{y}{t}{delay}\n"
 "\\newcommand{\\QTfigure}[5]  \n"
 "{\n"
 "	\\draw\n"
 "	($ (0 cm,0.4cm-.5*0.2*#2 cm) + % The QT length, shifted\n"
 "	(0 cm,0.1cm-#5*.2 cm) + % The delay of SV\n"
 "	(#3cm,-.2*#4cm)$) % The top of the QT block\n"
 "	 node[QT,minimum width=.2*#2cm,draw]\n"
 "	(Q#1) {#1}\n"
"	[-,thick,color=burntorange] \n"
"   (Q#1.east) |- ($ (Q#1.east) +(-.4cm,#5*.2cm+.06cm)$) -| ($ (Q#1.east) +(-.4cm,#5*.2cm+.06cm)$)\n"
"	[-,thick,color=burntorange] \n"
"   (Q#1.west) |- ($ (Q#1.west) +(-.4cm,-.06cm)$) -| ($ (Q#1.west) +(-.4cm,-.06cm)$)\n"
"	;\n"
"}\n";

plotfile << "% % Put a new suspended quasi-thread symbol to coordinates\n"
   "% % \\QTfigureSuspend{Name_index}{length}{x}{y}{t}{delay}\n"
 "\\newcommand{\\QTfigureSuspend}[5]  \n"
 "{\n"
 "   \\def\\temp{#2}\n"
 "   \\ifx\\temp\\empty\n"
 "	\\draw[-,thick,color=burntorange]\n"
 " (.5cm+#3cm,0.05cm-.2*#4cm) |-   ($ (.5cm+#3cm,.05cm-.2*#4cm) +(-.3cm,#5*.2cm+.11cm)$) -| ($ (.5cm+#3cm,.05cm-.2*#4cm) +(-.3cm,#5*.2cm+.11cm)$);\n"
 "	\\draw[very thick,  draw=blue!50!black!100, scale=\\scalefact]\n"
 "	($(-.2cm,0.1 cm) + (.5cm+#3cm,-.2*#4cm)$) -- ($(+.2 cm,0.1 cm) + (.5cm+#3cm,-.2*#4cm)$);\n"
 "  \\else\n"
"	\\draw\n"
 "	($ (0 cm,0.4cm-.5*0.2*#2 cm) + % The QT length, shifted\n"
 "	(0 cm,0.1cm-#5*.2 cm) + % The delay of SV\n"
 "	(#3cm,-.2*#4cm)$) % The top of the QT block\n"
 "	 node[QT,minimum width=.2*#2cm,draw]\n"
 "	(Q#1) {#1}\n"
"	[-,thick,color=burntorange] \n"
"   (Q#1.east) |- ($ (Q#1.east) +(-.3cm,#5*.2cm+.06cm)$) -| ($ (Q#1.east) +(-.4cm,#5*.2cm+.06cm)$)\n"
"	;\n"
"  \\fi\n}\n";

plotfile << "% % Put a new quasi-thread symbol to coordinates\n"
   "% % \\QTfigureResume{Name_index}{length}{x}{y}{t}{delay}\n"
 "\\newcommand{\\QTfigureResume}[5]  \n"
 "{\n"
 " \\def\\temp{#2}\n"
 " \\ifx\\temp\\empty\n"
 "	\\draw[-,thick,color=burntorange]\n"
 "  (.5cm+#3cm,-.2*#4cm) |- ($ (.5cm+#3cm,-.2*#4cm) +(-.3cm,-.06cm)$) -| ($ (.5cm+#3cm,-.2*#4cm) +(-.3cm,-.06cm)$);\n"
 "	\\draw\n"
 "	[very thick,  draw=blue!50!black!100, scale=\\scalefact]\n"
 "	($(-.2cm,0 cm) + (.5cm+#3cm,-.2*#4cm)$) -- ($(+.2 cm,0 cm) + (.5cm+#3cm,-.2*#4cm)$);\n"
 "\\else\n"
"	\\draw\n"
 "	($ (0 cm,0.4cm-.5*0.2*#2 cm) + % The QT length, shifted\n"
 "	(0 cm,0.1cm-#5*.2 cm) + % The delay of SV\n"
 "	(#3cm,-.2*#4cm)$) % The top of the QT block\n"
 "	 node[QT,minimum width=.2*#2cm,draw]\n"
 "	(Q#1) {#1}\n"
"	[-,thick,color=burntorange] \n"
"   (Q#1.west) |- ($ (Q#1.west) +(-.3cm,-.06cm)$) -| ($ (Q#1.west) +(-.4cm,-.06cm)$)\n"
"	;\n"
"  \\fi\n}\n";

 
plotfile << "% % \\QTwait{core}{time} Put a dot when the core is waiting\n"
 "\\newcommand{\\QTwait}[3]  \n"
 "{\n"
 "	\\draw\n"
 "	($ (0.14cm+#1 cm,-0.1cm-.2*#2 cm)$) node[circle, very thin, inner sep = 0.5 pt, draw, thick, color=blue!50!black!100, scale=0.55]\n"
 " 	(Q) {\\scriptsize #3}\n"
 "	;\n"
 "}\n";

plotfile << "% % \\QTSwait{core}{time} Put a dot when the core is waiting\n"
 "\\newcommand{\\QTSwait}[3]  \n"
 "{\n"
 "	\\draw\n"
 "	($ (0.14cm+#1 cm,-0.1cm-.2*#2 cm)$) node[circle, very thin, inner sep = 0.5 pt, draw, thick, color=red!50, scale=0.55]\n"
 " 	(Q) {\\scriptsize #3}\n"
 "	;\n"
 "}\n";

plotfile << "% % \\QTexec{core}{time}{PC}{ExecLength} Put a PC when executing instruction\n"
 "\\newcommand{\\QTexec}[4]  \n"
 "{\n"
 "	\\draw\n"
 " 	($ (0.90cm+#1 cm,-0.10cm-.2*#2 cm)$) node[inner sep = .5pt, circle,ball color=green, shading=ball, font=\\small\\bfseries, scale=0.65]\n"
 " 	(Q) { #3}\n"
"	;\n"
"  \\foreach \\y/\\ytext in {0,..., #4}\n"
"	\\draw\n"
 "	($ (0.84cm+#1 cm,-0.3cm-\\y*.2 cm-.2*#2 cm)$) node[circle,ball color=green, shading=ball,  font=\\bfseries, scale=0.55]\n"
 " 	(Q) {}\n"
 "	;\n"
/*"	\\draw\n"
 "	($ (0.84cm+#1 cm,-0.5cm-.2*#2 cm)$) node[circle,ball color=green, shading=ball,  font=\\bfseries, scale=0.55]\n"
 " 	(Q) {}\n"
 "	;\n"
"	\\draw\n"
 "	($ (0.84cm+#1 cm,-0.7cm-.2*#2 cm)$) node[circle,ball color=green, shading=ball,  font=\\bfseries, scale=0.55]\n"
 " 	(Q) {}\n"
 "	;\n"
"	\\draw\n"
 "	($ (0.84cm+#1 cm,-0.9cm-.2*#2 cm)$) node[circle,ball color=green, shading=ball,  font=\\bfseries, scale=0.55]\n"
 " 	(Q) {}\n"
 "	;\n"*/
 "}\n";

plotfile << "% % \\QTmeta{core}{time}{PC} Put a PC when executing metainstruction\n"
 "\\newcommand{\\QTmeta}[3]  \n"
 "{\n"
 "	\\draw\n"
 " 	($ (0.88cm+#1 cm,-0.1cm-.2*#2 cm)$) node[inner sep = 1pt,draw,rectangle,color=burntorange]\n"
 " 	(Q) {\\tiny #3}\n"
 "	;\n"
"}\n";

plotfile << "% % \\QTmetaparent{core}{time}{PC} Put a PC to the parent when creating a QT\n"
 "\\newcommand{\\QTmetaparent}[3]  \n"
 "{\n"
 "	\\draw\n"
 " 	($ (0.88cm+#1 cm,-0.1cm-.2*#2 cm)$) node[inner sep = 1pt,draw,rectangle,burntorange]\n"
 " 	(Q) {\\tiny #3}\n"
 "	;\n"
"}\n";

plotfile << "% % \\QTmassprocin{core}{time}{PC} Put a PC to the parent when creating a QT\n"
 "\\newcommand{\\QTmassprocin}[3]  \n"
 "{\n"
 "	\\draw\n"
 " 	($ (0.18cm+#1 cm,-0.1cm-.2*#2 cm)$) node[inner sep = 1pt,color=blue!50!black!100]\n"
 " 	(Q) {\\tiny <}\n"
 "	;\n"
"}\n";

plotfile << "% % \\QTmassprocout{core}{time}{PC} Put a PC to the parent when creating a QT\n"
 "\\newcommand{\\QTmassprocout}[3]  \n"
 "{\n"
 "	\\draw\n"
 " 	($ (0.18cm+#1 cm,-0.1cm-.2*#2 cm)$) node[inner sep = 1pt,color=blue!50!black!100]\n"
 " 	(Q) {\\tiny >}\n"
 "	;\n"
"}\n";

  plotfile << "\\def\\scalefact{1.0}\n"
  "\\tikzstyle{QT} = [top color=white, bottom color=blue!30,\n"
  "minimum height={0.7},rotate=90,scale=\\scalefact,xshift=-.5cm,yshift=-.5cm,\n"
                            " draw=blue!50!black!100, drop shadow] %, font=\\small]\n"
  "\n"
  "\\begin{document}\n"
  "\n"
  "\n%\\begin{figure*}[!bth]\n"
 "\\maxsizebox{\\textwidth}{\\textheight}\n"
 "{\n"
 "%	\\pgfplotsset{width=6.3cm}\n"
"\\centering\n"
"\\begin{tikzpicture}[scale=1.0]\n"
 "\n";

     PlotCoreAxis();
  } // of UNIT_TESTING
}

// Draw horizontal axis (cores)
void EMPAPlotter::PlotCoreAxis(void)
{
  if(!UNIT_TESTING)
  {
//    Processor* Proc = Processor_Get();
    plotfile << "\\node[right,above] at ( -.5 cm,.1cm) {$Cores$};\n";
    plotfile << "  \\foreach \\x/\\xtext in {0,...," << mProcessor->NoOfTotalCores_Get()-1 << "}\n";
    plotfile << "    \\draw[xshift=\\x cm+.5 cm,yshift=0.1cm]  node[above=.1] "
             "{$C_{\\xtext}$};\n";
  }
}

// Draw vertical axis (time)
void EMPAPlotter::PlotTimeAxis(void)
{
  if(!UNIT_TESTING)
  { 
 //   Processor* Proc = Processor_Get();
    unsigned int TimeMax = (mProcessor->SimulatedTime_Get()+4)/5 ;
    plotfile << "\\draw[style=help lines,step=1] (0,-" << TimeMax <<") grid (" << mProcessor->NoOfTotalCores_Get() << ",0);\n";
    plotfile << "\\node[rotate=90,above=.5] at (-0.6cm,-1.5cm) {$Instruction\\ times$};\n";

    plotfile << "  \\foreach \\y/\\ytext in {0,...," << TimeMax-1 << "}\n";
    plotfile << "    \\draw[yshift=-0.5cm-\\y cm,xshift=-0.1cm]     node[left] "
             "{$T_{\\ytext}$};\n" ;   
  }
}


/**
 * @brief Print a summary report at the end of processing
 * 
 * Print a summary table, which contains statistics of operation
 * @return void
 */
void EMPAPlotter::PrintFinalReport(void)
{
  if(!UNIT_TESTING)
  {
  Processor* Proc = Processor_Get();
  LOG(INFO) << "";
  LOG(INFO) << "      " << "Summary table";
  LOG(INFO) << "      " << "Object     " << "Exec  " << "Ctrl  " << "Wait  " << "Level "<< "Instr\n";
  LOG(INFO) << "      " << "Supervisor " << "   - " << std::setw(5) << setfill(' ') << Supervisor_Get()->ControlTime_Get() <<  "     0 " <<  "     - " << "    -\n";
  
  unsigned int texectime=0, tcontroltime=0, twaittime=0, tinstructions=0, tnestingmax=0;
  int NoOfCores = Proc->NoOfTotalCores_Get();
  for(int i = 0; i < NoOfCores; i++)
  {
    Core* C = Proc->Core_GetByID(i);
    unsigned int exectime = C->ExecTime_Get();
    unsigned int controltime = C->ControlTime_Get();
    unsigned int waittime = C->WaitTime_Get();
    unsigned int nestingmax = C->NestingMax_Get();
    
    if(exectime+controltime+waittime)
    { // The core was active during this run, 
      texectime += exectime; tcontroltime += controltime; twaittime += waittime; tnestingmax += nestingmax;
      tinstructions += C->ExecutedInstructions_Get();
      ostringstream LogInfo;
      LogInfo << "Core(" << std::setw(2) << std::setfill('0') << i << ")  "
      << std::setw(5) << setfill(' ')<< std::setw(5) << exectime << " "<< std::setw(5) << controltime << " " 
      << std::setw(5) << waittime << " " << std::setw(5) << nestingmax << " " << std::setw(5) << C->ExecutedInstructions_Get() << endl;
      LOG(INFO) << "      " << LogInfo.str();
     }
  }
  ostringstream LogInfo;
  LogInfo << "Total     " << std::setw(5) << setfill(' ') << texectime << " "
  << std::setw(5) << tcontroltime+Supervisor_Get()->ControlTime_Get() << " " 
  << std::setw(5) << twaittime << " " << std::setw(5) << tnestingmax << " " << std::setw(5) << tinstructions << "\n";
  LOG(INFO) << "      " << LogInfo.str() ;
  LOG(INFO) << "      SimTime   "  << std::setw(5) << setfill(' ') << Proc->SimulatedTime_Get() << "\n";
//  cerr << LogInfo.str();
/*  if(!Proc->SimulatedTime_Get()) return;
  float S = texectime/ float(Proc->SimulatedTime_Get());
  float alphaeff;
  if(NoOfCores>1 && S>0 && texectime)
  {
    alphaeff = NoOfCores/float(NoOfCores-1)*(S-1)/S;
//    cerr << "Speedup=" << S  << ", alphaeff=" << alphaeff << '\n';
    plotfile << setprecision(3)  << "\\node[right,above] at ( 0.5 cm,.5cm) {S=" << S ;
    if(alphaeff>0)
    {
      plotfile << ", $\\alpha_{eff}$=" << alphaeff;
      LOG(INFO) << "      "  << setprecision(3) << "Speedup=" << S  << ", alphaeff=" << alphaeff;
    }
    else
      LOG(INFO) << "      "  << setprecision(3) << "Speedup=" << S ;
    plotfile << "};\n";
  }
  else
  {
    LOG(INFO) << "      "  << setprecision(3) << "Speedup=" << S;
    plotfile << setprecision(3) << "\\node[right,above] at ( 0.1 cm,.5cm) {S=" << S << "};\n";
  };
  */
  } // UNIT_TESTING
}

// Put a dot when the core is waiting
void EMPAPlotter::PlotQTwait(int CoreNum, unsigned int Time, unsigned int PC)
{
  if(!UNIT_TESTING)
  {
      WaitString << "\\QTwait{" << CoreNum << "}{" << Time << "}{" << std::setw(2) << hex << setfill('0') << PC << dec << "}\n" ;
  }
}

// Put a dot when the core is waiting
void EMPAPlotter::PlotQTSwait(int CoreNum, unsigned int Time, unsigned int PC)
{
  if(!UNIT_TESTING)
  {
     WaitString << "\\QTSwait{" << CoreNum << "}{" << Time << "}{" << std::setw(2) << hex << setfill('0') << PC << dec << "}\n" ;
  }
}

// % % \QTexec{x}{t}{PC} Put a dot when the core is waitin1
// % % X : core physical number;  t : The absolute time; PC 
// Put ball with memory address when executing instruction
void EMPAPlotter::PlotQTexec(unsigned int CoreNum, unsigned int Time, unsigned int PC, unsigned int ExecLength)
{
  if(!UNIT_TESTING)
  {
    ExecString << "\\QTexec{" << CoreNum << "}{" << Time << "}{" << std::setw(2) << hex << setfill('0') << PC << dec << "}{" << ExecLength-2 << "}\n";
  }
}

// Put a rectangle with memory address when executing metacommand
void EMPAPlotter::PlotQTmeta(unsigned int CoreNum, unsigned int Time, unsigned int PC)
{
  if(!UNIT_TESTING)
  {
    MetaString << "\\QTmeta{" << CoreNum << "}{" << Time << "}{" << std::setw(2) << hex << setfill('0') << PC << dec << "}\n";
  }
}

// Put a rectangle with memory address when executing metacommand
void EMPAPlotter::PlotQTmetaparent( int CoreNum, unsigned int Time, unsigned int PC)
{
  if(!UNIT_TESTING)
  {
    MetaString << "\\QTmetaparent{" << CoreNum << "}{" << Time << "}{" << std::setw(2) << hex << setfill('0') << PC << dec << "}\n";
  }
}

// Put a rectangle with memory address when executing metacommand
void EMPAPlotter::PlotQTmassprocin( int CoreNum, unsigned int Time, unsigned int PC)
{
  if(!UNIT_TESTING)
  {
    MetaString << "\\QTmassprocin{" << CoreNum << "}{" << Time << "}{" << std::setw(2) << hex << setfill('0') << PC << dec << "}\n";
  }
}

// Put a rectangle with memory address when executing metacommand
void EMPAPlotter::PlotQTmassprocout( int CoreNum, unsigned int Time, unsigned int PC)
{
  if(!UNIT_TESTING)
  {
    MetaString << "\\QTmassprocout{" << CoreNum << "}{" << Time << "}{" << std::setw(2) << hex << setfill('0') << PC << dec << "}\n";
  }
}


// % Put a new queue symbol to coordinates, the new, 5-parameter version
// % \QTfigure{Name_index}{length}{x}{y}{t}{delay}
// % #1 Name: name of QT, just a string
// % #2 Length: length of QT, clock ticks
// % #3 x : core sequence number
// % #4 y : Begin of QT time
// % #5 delay: before QT could start
// 
// The figure represents the lifetime of a quasi-thread, i.e. begins at QCreate, terminates at QTerm
// at the top and bottom, two hooks represent the control actions by the supervisor
void EMPAPlotter::PlotQTfigure(string Name, unsigned int Length, unsigned int Core, unsigned int Time, unsigned int Delay )
{
  if(!UNIT_TESTING)
  {
    char Type = Name.at(0); std::string Index = Name.substr(1,Name.length()-1);
    QTstring << "\\QTfigure{$" << Type << "_{" << Index << "}$}{" <<
                Length << "}{" << Core << "}{" << Time+1 << "}{"  << Delay <<  "}\n";
  }
}


// Same as PlotQTfigure, but without top hook
void EMPAPlotter::PlotQTfigureResume(string Name, unsigned int Length, unsigned int Core, unsigned int Time, unsigned int Delay )
{
  if(!UNIT_TESTING)
  {
    char Type = Name.at(0); std::string Index = Name.substr(1,Name.length()-1);
    QTstring << "\\QTfigureResume{$" << Type << "_{" << Index << "}$}{";
    if(Length) QTstring << Length; 
    QTstring << "}{" << Core << "}{" << Time << "}{"  << Delay <<  "}\n";
  }
}



// Same as PlotQTfigure, but without bottom hook
void EMPAPlotter::PlotQTfigureSuspend(string Name, unsigned int Length, unsigned int Core, unsigned int Time, unsigned int Delay )
{
  if(!UNIT_TESTING)
  {
    char Type = Name.at(0); std::string Index = Name.substr(1,Name.length()-1);
    QTstring << "\\QTfigureSuspend{$" << Type << "_{" << Index << "}$}{" ;
    if(Length) QTstring << Length; 
    QTstring  << "}{" << Core << "}{" << Time << "}{"  << Delay <<  "}\n";
  }
}
