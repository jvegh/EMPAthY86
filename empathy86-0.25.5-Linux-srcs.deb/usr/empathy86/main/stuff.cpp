/** @file stuff.cpp
 *  @brief Some utility routines for the EMPA processor simulator.
 *
 *  @author János Végh (jvegh)
 *  @bug No known bugs.
 */
#include <fstream>      // std::ifstream
#include <gtest/gtest.h>
#include <glog/logging.h>
#include <stdlib.h>
#include "Config.h"
#include "stuff.h"
#include "Plot.h"

extern string PlotMessage;	// The early string, before logging
extern bool UNIT_TESTING;
using namespace std;

bool GUI_MODE;	// This tells whether routine run in GUI mode

  void
CheckArgumentList(int argc, char** argv)
{
  ostringstream  logintext;
  if(argc < 3)
  {
    logintext  << " correct usage:\n" << argv[0] << " FileName.Eyo  NProc";
    cout << logintext.str() << endl; // Print out a kind of help, no logging yet
    exit (EXIT_FAILURE);
  }
}


  Processor*
CreateProcessorAndLoadProgram(char** argv)
{
  if(GUI_MODE)
    {
      return  (Processor*) NULL;
    }

  // This is either the text version of the simulator or unit testing framework
  Memory* Mem = new Memory();  // Create a new memory
  if(!Mem->loadFile(argv[1]))  // Attempt to load the given file
  {
    LOG(ERROR) << "         " << "Failed to load object file '" << argv[1] << "'  into memory";
    return (Processor*) NULL;
  }
  char* pEnd;
  int NCores = strtol(argv[2], &pEnd, 10);
  {
    if(NCores<0 || NCores>32)
    {
	cerr << "No of cores must be between 1 and 32\n";
    }
  }
  string FileNameRoot = GetFileNameRoot( argv[1])+"_"+string(argv[2]);
  Processor* Proc = new Processor(Mem, FileNameRoot, NCores);
  return Proc;
}


void
OpenSystemFiles(const char* FileName, const char* LogFileName, string Heading)
{
  // Prepare and start logging
//  string FileRoot = GetFileNameRoot(FileName); // Prepare log file name
  FLAGS_alsologtostderr = 1; // Log also to the screen
  testing::internal::CaptureStdout();
  google::InstallFailureSignalHandler();
  google::SetLogDestination(0, (string(LogFileName)).c_str());
  google::InitGoogleLogging(FileName);
  LOG(INFO) << " " << Heading;
  LOG(INFO) << " Log file for this run: \"" << LogFileName << "\"";
  LOG(INFO) << " LOG message format: glog header] " << GetAppName() << " header : " << GetAppName() << " message";
  LOG(INFO) << " " << GetAppName() << " header: @simulated time[memory address]Core number <QT name> : ";
}

//http://stackoverflow.com/questions/3803465/how-to-capture-stdout-stderr-with-googletest

void CloseSystemFiles(string Trailing)
{
  std::string output = testing::internal::GetCapturedStdout(); // Write out the captured log info
  LOG(INFO) <<  endl << output;
  LOG(INFO) << " " << Trailing;
}

  string
GetAppName(void)
{
  std::ostringstream appname;
  appname << EMPAthY86e_NAME << " V" << EMPAthY86e_VERSION;
  return appname.str();
}

/*  string
GetAppVersion(void)
{
  std::ostringstream appversion;
  appversion << " V" << EMPAthY86e_VERSION;
  return appversion.str();
}*/



// Prepare a kind of file name fragment for created files
string GetFileNameRoot(string DataFileName)
{
  size_t fbegin = DataFileName.find_last_of('/');
  string FileNameRoot; 
  if(0==fbegin)
    FileNameRoot = DataFileName;
  else
    FileNameRoot = DataFileName.substr(fbegin+1); // Remove path first, if any
  fbegin = FileNameRoot.find_last_of('.');
  if(fbegin)
    FileNameRoot = FileNameRoot.substr(0,fbegin); // Remove extension, if any
    ostringstream FileNameFragment;
if(GUI_MODE)
    FileNameFragment << GetAppName() << "_GUI";
else
    if(UNIT_TESTING)
      FileNameFragment << GetAppName() << "_tst" ;
    else
      FileNameFragment << GetAppName() << "_txt_" << FileNameRoot;

    string S = FileNameFragment.str();
    size_t found = S.find(" "); // Replace " " with "-" in file name
    S.replace(found,1,"-"); 
    return S;
}

