#include <gtest/gtest.h>
#include <glog/logging.h>
#include "../main/include/stuff.h"
#include "../libEMPA/include/Utils.h"
#include "../libEMPA/include/Core.h"
#include "../libEMPA/include/Processor.h"

/** @class	StuffTest
 * @brief	Tests EMPA processor stuff functionality
 * 
 */

extern Processor* Proc; // The singleton processor, defined in Processor.cpp
extern bool UNIT_TESTING;		// Switched off by default
extern KeyCode FindCode(string Key, int Lineno); // For searching metacommand keys
extern char arg2[];
extern char arg1[];
extern char arg0[];
extern bool OBJECT_FILE_PRINTED;
// A new test class  of these is created for each test
class StuffTest : public testing::Test
{
public:
    int NoOfCores;
    Supervisor* Super;   // Get our supervisor
    Processor* Proc;
    EMPAPlotter* Plotter;
    char* a[3];
public:

};
 
/**
 * Tests some routines of the stuff
 */
TEST_F(StuffTest, Tools)
{
    // An illegal mask (no 'hot' bit results in ID '-1)
    EXPECT_EQ((unsigned int) -1 , MaskToID(0) );
    // An 'all ones', 32-bit value results in the highest ID possible
    EXPECT_EQ((unsigned int) 31 , MaskToID((unsigned int)-1) );
    
    // ID 0 results in mask 0x0001
    EXPECT_EQ(1 , IDtoMask(0) );
    // ID 5 results in mask 2**5 = 0x0020
    EXPECT_EQ(32 , IDtoMask(5) );
    // ID 35 is illegal ID, results in mask 0
    EXPECT_EQ(0 , IDtoMask(35) );
    string MySimpleFileName = "asum.Eyo";
    string MyRelativeFileName = "~MyPath/../files/asum.Eyo";
    EXPECT_EQ("asum.Eyo", GetFileNameRoot(MyRelativeFileName));
    EXPECT_EQ("asum.Eyo", GetFileNameRoot(MySimpleFileName));
}

