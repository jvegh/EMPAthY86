#include <gtest/gtest.h>
#include <glog/logging.h>
#include "../main/include/stuff.h"
#include "../libEMPA/include/Utils.h"
#include "../libEMPA/include/Core.h"
#include "../libEMPA/include/Processor.h"

extern bool UNIT_TESTING;		// Switched off by default
extern char arg2[];
extern char arg1[];
extern char arg0[];

// A new test class  of these is created for each test
class InitTest : public testing::Test
{
public:
    int NoOfCores;
    Supervisor* Super;   // Get our supervisor
    Processor* Proc;
    EMPAPlotter* Plotter;
    Memory* Mem;
public:

   virtual void SetUp()
   {
      Mem = new Memory();  // Create a new memory
      Proc = new Processor(Mem, "JustTest.tst", NoOfCores);
      Plotter = Proc->Plotter_Get();
      Super = Proc->Supervisor_Get();
      NoOfCores = Proc->NoOfTotalCores_Get();
   }

   virtual void TearDown()
   {
     delete Proc;
   }
};
 
/**
 * Tests the initial state of core status settings
 */
TEST_F(InitTest, Static)
{
  Mem->setByte(0,0);
  Core* C0 = Proc->Core_GetByID(0);
  EXPECT_EQ(NoOfCores, Proc->NoOfTotalCores_Get());	// Initially we have 8 cores
  EXPECT_EQ(0, Proc->PC_Get());	// The processor is initialized to address 0
  EXPECT_EQ(0,C0->PC_Get());	// Also the cores are initialized to 0
  EXPECT_EQ(0,C0->PreallocatedMask_Get());	// Nothing is preallocated for C0
  EXPECT_TRUE(C0->IsAvailable());	// C0 is initially available
  EXPECT_EQ(0,Super->CoresUnavailableMask_Get()); // Nothing yet is unavailable
  EXPECT_EQ(0,Super->CoresDisabledMask_Get());	// Nothing disabled
  EXPECT_EQ(0,Super->CoresAllocatedMask_Get());	// Nothing allocated
  EXPECT_EQ(0,Super->CoresPreallocatedMask_Get());	// Nothing preallocated
  C0->Allocated_Set();	// Allocate C0
  EXPECT_FALSE(C0->IsAvailable());	// C0 is not any more available
  EXPECT_EQ(1,Super->CoresUnavailableMask_Get()); // Only C0 is unavailable
  EXPECT_EQ(0,Super->CoresDisabledMask_Get());	// Nothing disabled
  EXPECT_EQ(1,Super->CoresAllocatedMask_Get());	// Nothing allocated
  EXPECT_EQ(0,Super->CoresPreallocatedMask_Get());	// Nothing preallocated
  Core* C1 = Proc->Core_GetByID(1);
  EXPECT_TRUE(C1->IsAvailable());	// C1 is available
  C1->Disabled_Set();	//	
  EXPECT_EQ(3,Super->CoresUnavailableMask_Get()); // C0 and C1 are unavailable
  EXPECT_EQ(2,Super->CoresDisabledMask_Get());	// C1 disabled
  EXPECT_EQ(1,Super->CoresAllocatedMask_Get());	// Only C0 is allocated
  EXPECT_EQ(0,Super->CoresPreallocatedMask_Get());	// Nothing preallocated
  Core* C2 = Proc->Core_GetByID(2);
  EXPECT_TRUE(C2->IsAvailable());	// C1 is available
  C2->Preallocated_Set();	// Prellocate C2
  EXPECT_EQ(7,Super->CoresUnavailableMask_Get()); // C0, C1 and C2 are unavailable
  EXPECT_EQ(2,Super->CoresDisabledMask_Get());	// C1 disabled
  EXPECT_EQ(1,Super->CoresAllocatedMask_Get());	// C0 is allocated
  EXPECT_EQ(4,Super->CoresPreallocatedMask_Get());	// C2 preallocated
  EXPECT_FALSE(C1->IsAvailable());	// C1 is not any more available
  EXPECT_FALSE(C2->IsAvailable());	// C2 is not any more available
  EXPECT_TRUE(Proc->Core_GetByID(3)->IsAvailable());	// C3 is still available
  Super->CoresPreallocatedMask_Set(0);	// Clear all preallocations
  EXPECT_TRUE(C2->IsAvailable());	// C2 is free again
  Super->CoresAllocatedMask_Set(0);	// Clear all preallocations
  EXPECT_TRUE(C0->IsAvailable());	// C1 is free again
  Super->CoresDisabledMask_Set(0);	// Clear all preallocations
  EXPECT_TRUE(C1->IsAvailable());	// C1 is free again
}

/**
 * Tests the core allocation/deallocation
 */
TEST_F(InitTest, Allocate)
{
  // Check without preallocation
  Super->CoresAllocatedMask_Set(0);	// Clear all preallocations
  Core* C0 = Proc->Core_GetByID(0);
  C0->Allocate(NULL);
  EXPECT_EQ(1,Super->CoresAllocatedMask_Get());	// C0 is allocated

  C0->Deallocate();
  EXPECT_EQ(0,Super->CoresAllocatedMask_Get());	// C0 is allocated
  
  // Check with preallocation
//  Super->CoresPreallocatedMask_Set(0);	// Clear all preallocations
  Core* C1 = Proc->Core_GetByID(1);
  Core* C2 = Proc->Core_GetByID(2);
  EXPECT_EQ(0,Super->CoresUnavailableMask_Get()); // Nothing is unavailable
  C0->Preallocated_Set(2);
  EXPECT_EQ(2,Super->CoresUnavailableMask_Get()); // Now C1 is preallocated
  C2->Allocate(C0);
  
  // C1 is preallocated for C0, and we allocate C2 for C0
  EXPECT_EQ(4,Super->CoresAllocatedMask_Get());	// C0 is allocated
  EXPECT_EQ(6,Super->CoresUnavailableMask_Get()); // C1 is preallocated, C2 is allocated for C0
  EXPECT_EQ(0, C2->Parent_Get()->ID_Get());	// Parent of C2 is C0
  EXPECT_EQ(C2->IDMask_Get(), C0->ChildrenMask_Get());	// Only C2 is allocated for C0
  EXPECT_EQ(2,C0->PreallocatedMask_Get());	// The preallocation is unchanged at core
  EXPECT_EQ(2,Super->CoresPreallocatedMask_Get()); // and at supervisor
  EXPECT_EQ(4,Super->CoresAllocatedMask_Get()); // The allocation is not changed
  EXPECT_EQ(2+4,Super->CoresUnavailableMask_Get()); // Now C1 is preallocated, C2 allocated
  
  // Now allocate the preallocated core
  C1->Allocate(C0); // The core must be preallocated, while allocated
  EXPECT_EQ(C1->IDMask_Get()+C2->IDMask_Get(), C0->ChildrenMask_Get());	// Both C1 and C2 is allocated for C0
  EXPECT_EQ(6,Super->CoresUnavailableMask_Get()); // C1 is preallocated, C2 is allocated for C0
  EXPECT_EQ(2,C0->PreallocatedMask_Get());	// The preallocation is unchanged, at core
  EXPECT_EQ(2,Super->CoresPreallocatedMask_Get()); // and at supervisor
  EXPECT_EQ(6,Super->CoresAllocatedMask_Get()); // and at supervisor
  EXPECT_EQ(2+4,Super->CoresUnavailableMask_Get()); // Now C1 is preallocated, C2 allocated
  C1->Deallocate();
  EXPECT_EQ(2,Super->CoresPreallocatedMask_Get()); // C1 remains preallocated
  EXPECT_EQ(4,Super->CoresAllocatedMask_Get()); // but not allocated any more
  EXPECT_EQ(2+4,Super->CoresUnavailableMask_Get()); // Now C1 is preallocated, C2 allocated
  EXPECT_EQ(C2->IDMask_Get(), C0->ChildrenMask_Get());	// Only C2 is allocated for C0
  EXPECT_EQ(NULL,C1->Parent_Get());	//C1 has no parent 
}
