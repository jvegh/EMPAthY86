
#include <iostream>
#include <sstream>
#include <glog/logging.h>
#include <gtest/gtest.h>
#include "../main/include/stuff.h"
#include "../main/include/Config.h"
//#include "Constants.h"
#include "../main/include/Plot.h"
#include "../libEMPA/include/Utils.h"
#include "Processor.h"
extern EMPAPlotter* Plotter;  //Defined in Plot.cpp
extern bool UNIT_TESTING;	// Whether in course of unit testing
extern bool GUI_MODE;		// Whether running under Qt5 GUI
extern bool OBJECT_FILE_PRINTED;

using namespace std;

#include "../libEMPA/include/Core.h"
/**
 * @brief This is the main file of the many-core simulator
 * 
 * @param argc Number of parameters
 * @param argv parameters, #1 is the name of the command file
 * @return int The result of the execution
 */
  char arg0[20]; // Application name
  char arg1[40]; // Test file name
  char arg2[10]; // No of cores
//  void RunPlotTest(int argc, char **argv);
//  string ModuleName = "Main";

extern instr_t instruction_set[];
 word_t QCreate_Size; 
  // gtest runs in multithread mode, so we must have per thread (i.e. per test case) Processor
  
int main(int argc, char **argv) {
/*
  char* a[3];
  a[0] = arg0;
  a[1] = arg1;
  a[2] = arg2;
#ifdef EMPA_MODE
  a[2] = (char*)"1";
#endif // EMPA_MODE
*/
//  CheckArgumentList(argc, argv);
  GUI_MODE = false;    // During testing, no GUI used
  UNIT_TESTING = true; // During unit testing, disable output to the screen
  OBJECT_FILE_PRINTED = false; // Do not print object file multiple times
//  CheckArgumentList(argc, argv);

  QCreate_Size = instruction_set[0].bytes;	// This value is used for address calculations

  ostringstream Heading;
  Heading << GetAppName() << " simulator tests has started";
  string LogFileName = "../output/test_"+GetFileNameRoot();
  string FileRoot = GetFileNameRoot() +'_'; // Prepare log file name
  OpenSystemFiles(FileRoot.c_str(), LogFileName.c_str(), Heading.str());
    // Create a processor, for assembling test output file name 
/*  Processor* Proc = CreateProcessorAndLoadProgram(a);
  if(!Proc)
     LOG(FATAL) << "Processor creation using simulator file " << a[1] << " failed";
*/
  testing::InitGoogleTest(&argc, argv);
/* LOG(INFO) << Heading.str();
  LOG(INFO) << "Prefix of files for this run: \"" << FileRoot.c_str() << "\"";
  LOG(INFO) << "LOG message format: glog header] " << GetAppName() << " : " << GetAppName() << " message";
  LOG(INFO) << "simEMPA header: @simulated time[memory address]Core number <QT name> : ";

delete Proc; // The temporary processor is removed, the tests create their own ones
*/  // The simulator functions also prepare some LaTeX plots, open the plotter
  // if(UNIT_TESTING) all interfaces are valid, but there is no functionality, no file
  int returnValue;
    //Do whatever setup here you will need for your tests here
    //
    //
  returnValue =  RUN_ALL_TESTS();
    //Do Your teardown here if required
    //
    //
  ostringstream Trailing;
  Trailing << GetAppName() << " simulator tests has terminated";
  CloseSystemFiles(Trailing.str());
/*#ifdef EMPA_MODE  
  RunPlotTest(2, a);	// Run plotting quasi-tests 
#endif // EMPA_MODE  
*/  return returnValue;
}

// This 'test' is for testing the plotting facilities
// Normally, plotting is disabled during unit testing, so
// for the time of this test, plotting must be enabled.
// In order NOT to interfere with other tests, it runs
// after  RUN_ALL_TESTS, so the multithreaded gtest
// will not confuse output data

#ifdef EMPA_MODE  
void RunPlotTest(int argc, char **argv)
{
      UNIT_TESTING = 0;
  Processor* Proc = CreateProcessorAndLoadProgram(argv);
  //    Processor* Proc = CreateProcessorAndLoadSimulatorCommands(argc, argv);
      if(!Proc)
        LOG(FATAL) << "Processor creation using simulator file " << "../../empafiles/CACM_Test.mcs" << " failed";
      EMPAPlotter* Plotter = Proc->Plotter_Get();
      if(!Plotter)
        LOG(FATAL) << "Plotter creation using simulator file " << "../../empafiles/CACM_Test.mcs" << " failed";
     // Now the requisites are in order, proceed
       LOG(INFO) << "Testing LaTeX/tikz plotting/printing routines";
       //PlotQTwait(unsigned int CoreNum, unsigned int Time);
       //PlotQTexec(unsigned int CoreNum, unsigned int Time, unsigned int PC);
       //PlotQTmeta(unsigned int CoreNum, unsigned int Time, unsigned int PC);
       //PlotQTfigure(string Name, unsigned int Length, unsigned int Core, unsigned int Time, unsigned int Delay );
       //PlotQTfigureResume(string Name, unsigned int Length, unsigned int Core, unsigned int Time, unsigned int Delay );
       //PlotQTfigureSuspend(string Name, unsigned int Length, unsigned int Core, unsigned int Time, unsigned int Delay );
       Plotter->PlotQTfigure("My", 0, 1, 20, 0 );
       Plotter->PlotQTfigure("Q_{ab}",15, 0, 5, 0 );
       Plotter->PlotQTfigureResume("Resumed", 8, 6, 15, 0 );
       Plotter->PlotQTfigureSuspend("Suspend", 9, 5, 5, 0 );
       ostringstream oss;
       oss <<  setw(2) << setfill('0') << hex << Proc->PC_Get() << dec;
       Plotter->PlotQTwait(0, 5,15);
       Plotter->PlotQTexec(0, 7, 5, 3);
       Plotter->PlotQTmeta(0, 12, 15);

       Plotter->PlotQTfigureResume("Resumed", 0, 2, 5, 0 );
       Plotter->PlotQTfigureSuspend("Suspend", 0, 3, 5, 0 );
       
       // From now on, can draw      
       Proc->SimulatedTime_Set(62); // Set the simulated time to the drawing scale
 // 
       delete Proc;	// Before exiting, remove our private Proc, close plot file
       UNIT_TESTING = 1;	// Disable messages during testing
}
#endif // EMPA_MODE  

