#include <gtest/gtest.h>
#include <glog/logging.h>
//#include "BaseTest.h"
#include "../main/include/stuff.h"
#include "../libEMPA/include/Utils.h"
#include "../libEMPA/include/Core.h"
#include "../libEMPA/include/Processor.h"


extern Processor* Proc; // The singleton processor, defined in Processor.cpp
extern bool UNIT_TESTING;		// Switched off by default
extern char arg2[];
extern char arg1[];
extern char arg0[];

// A new test class  of these is created for each test
class Y86Test : public testing::Test
{
public:
    int NoOfCores;
    Supervisor* Super;   // Get our supervisor
    Processor* Proc;
    EMPAPlotter* Plotter;
    Memory* Mem;
public:

   virtual void SetUp()
   {
      Mem = new Memory();  // Create a new memory
      Proc = new Processor(Mem, "JustTest.tst", 8);
      Plotter = Proc->Plotter_Get();
      Super = Proc->Supervisor_Get();
      NoOfCores = Proc->NoOfTotalCores_Get();
   }
//  
   virtual void TearDown()
   {
     delete Proc;
   }
   
};
 
/**
 * Tests some instructions of the Y86
 */
TEST_F(Y86Test, Static)
{
  Mem->setByte(0,0);
  Core* C0 = Proc->Core_GetByID(0);
  EXPECT_EQ(STAT_HLT, C0->MakeAStep("Just test"));
/*  Core* C = Proc->Core_GetByID(0);
  EXPECT_TRUE(C->IsMeta());   // The second instruction is NOT meta
  EXPECT_EQ(0xf5,C->Code_Get(0));	// The first code is an 'QCreate'
  EXPECT_EQ(0xfF,C->Code_Get(1));	// The first code is a 'register %eno'
  EXPECT_EQ(0x30, C->Code_Get(0x0c));	// It is a 'halt'
  */
}

/**
 * Tests simulator files-related operations
 */
TEST_F(Y86Test, Operation)
{
#ifdef EMPA_MODE
#else
    Core* C = Proc->Core_GetByID(0);
    Memory* M = Proc->Memory_Get();
    C->MakeAStep("");
    EXPECT_EQ(C->PC_Get(),6);	// The first instruction is 6 bytes long
    EXPECT_EQ(C->RegisterValue_Get(R_ESP),0x100);	// The SP is loaded with 'Stack' = 256
    EXPECT_EQ(C->RegisterValue_Get(R_EBP),0x0);	// The BP is still 0
//    C->ResetPending();
    C->MakeAStep("");
    EXPECT_EQ(C->RegisterValue_Get(R_EBP),0x100);	// The BP is loaded with 'Stack' = 256
    EXPECT_EQ(C->PC_Get(),12);	// The second instruction is 6 bytes long
//    C->ResetPending();
    C->MakeAStep("");
    EXPECT_EQ(C->PC_Get(),0x24);	// The 'call' moves to 0x24
    EXPECT_EQ(C->RegisterValue_Get(R_ESP),0x100-4);	// decreases SP by 4
    EXPECT_EQ(M->getWord(0),0x100f430);
    EXPECT_EQ(M->getWord(0xFC),0xc);	// and loads return address to the stack memory
    EXPECT_EQ(M->getByte(0xFC),0xc);
#endif
}


