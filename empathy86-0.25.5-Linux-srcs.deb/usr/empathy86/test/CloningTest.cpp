#include <gtest/gtest.h>
#include <glog/logging.h>
#include "../main/include/stuff.h"
#include "../libEMPA/include/Utils.h"
#include "../libEMPA/include/Core.h"
#include "../libEMPA/include/Processor.h"

extern bool UNIT_TESTING;		// Switched off by default
extern char arg2[];
extern char arg1[];
extern char arg0[];

// A new test class  of these is created for each test
class CloningTest : public testing::Test
{
public:
    int NoOfCores;
    Supervisor* Super;   // Get our supervisor
    Processor* Proc;
    EMPAPlotter* Plotter;
    Memory* Mem;
public:

   virtual void SetUp()
   {
      Mem = new Memory();  // Create a new memory
      Proc = new Processor(Mem, "JustTest.tst", NoOfCores);
      Plotter = Proc->Plotter_Get();
      Super = Proc->Supervisor_Get();
      NoOfCores = Proc->NoOfTotalCores_Get();
   }

   virtual void TearDown()
   {
     delete Proc;
   }
};
 
/**
 * Tests the cloning routines
 */
TEST_F(CloningTest, Create)
{
  Core* C0 = Proc->Core_GetByID(0);
  C0->PC_Set(123); // Set up some initial values for PC
  C0->RegisterValue_Set(R_EAX, 456); // and some registers
  C0->RegisterValue_Set(R_EBP, 234);

  Core* C1 = Proc->Core_GetByID(1);
  EXPECT_EQ(0,C1->PC_Get());
  C1->Allocate(C0);	// Now clone PC
  EXPECT_EQ(123,C1->PC_Get());
  C1->CloneRegisterFile(C0); // Clone all internal registers (Updates PC!)
  EXPECT_EQ(456,C1->RegisterValue_Get(R_EAX));
  EXPECT_EQ(234,C1->RegisterValue_Get(R_EBP));
}

/**
 * Tests the core allocation/deallocation
 */
TEST_F(CloningTest, Backlink)
{
  Core* C2 = Proc->Core_GetByID(2);
  C2->PC_Set(123); // Set up some initial values for PC
  C2->RegisterValue_Set(R_EAX, 456); // and some registers
  C2->RegisterValue_Set(R_EBP, 234);
  
  Core* C3 = Proc->Core_GetByID(3);
  C3->Allocate(C2);	// Now clone PC
  C3->CloneRegisterFile(C2); // Clone all internal registers 
  EXPECT_EQ(C3->PC_Get(),C2->PC_Get()+6);	//(Updates PC!)
  C2->RegisterValue_Set(R_EAX, 654); // Change some registers
  C2->RegisterValue_Set(R_EBP, 432);

  EXPECT_EQ(456,C3->RegisterValue_Get(R_EAX));
  EXPECT_EQ(234,C3->RegisterValue_Get(R_EBP));
  EXPECT_EQ(654,C2->RegisterValue_Get(R_EAX));
  EXPECT_EQ(432,C2->RegisterValue_Get(R_EBP));
  C3->Deallocate();	// Just release it
}

/**
 * Tests the core allocation/deallocation
 */
TEST_F(CloningTest, RegisterAccess)
{
  Core* C2 = Proc->Core_GetByID(2);	// Will be the parent
  C2->PC_Set(123); // Set up some initial values for PC
  Core* C3 = Proc->Core_GetByID(3);
  C3->Allocate(C2);	// Now clone PC
  C2->RegisterValue_Set(R_EAX, 456); // Set some registers
  EXPECT_EQ(0,C3->RegisterValue_Get(R_EAX));	// Still 0
  C3->RegisterValue_Set(R_ESV, 234, true);	// Simulate cloning 
  EXPECT_EQ(C3->FromChild_Get(),234);	// It is written to FromChild
  C3->RegisterValue_Set(R_ESV, 345, false);	// Simulate normal write 
  EXPECT_EQ(C3->ForParent_Get(),345);	// It is read from FromChild
  
  C2->MassOperatingMode_Set(5);
  C3->ParentMode_Set(5);
  C3->RegisterValue_Set(R_ESV, 124, false);	// Simulate normal write 
  EXPECT_NE(124,C2->RegisterValue_Get(R_ESV));
  C3->RegisterCloneBack(R_ESV);	// Save in a temporary store
  
}
